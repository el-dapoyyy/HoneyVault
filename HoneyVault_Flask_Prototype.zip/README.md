# HoneyVault Flask Prototype
Prototype akademik untuk menguji Adaptive Decoy Generation pada dataset pelanggan sintetis.

## Menjalankan di Windows
1. Ekstrak ZIP.
2. Buka terminal pada folder HoneyVault_Flask_Prototype.
3. Jalankan `py -m venv .venv`
4. Aktifkan: `.venv\\Scripts\\activate`
5. Install: `pip install -r requirements.txt`
6. Jalankan: `python app.py`
7. Buka `http://127.0.0.1:5000`.

## Fitur
- Dashboard pelanggan fiktif dan penambahan data.
- Profil statistik saldo: mean, median, standar deviasi, minimum, maksimum.
- Random Decoy sebagai baseline.
- Adaptive Decoy berbasis distribusi normal dan rentang saldo dataset.

## Batasan penting
Aplikasi ini BELUM mengimplementasikan Honey Encryption sesungguhnya. Belum ada DTE (Distribution-Transforming Encoder), enkripsi, autentikasi, atau perlindungan data produksi. Ini adalah prototipe untuk menguji satu komponen usulan, yaitu generator decoy adaptif. Gunakan data sintetis saja; jangan masukkan data pelanggan nyata. Server debug hanya untuk pengembangan lokal.

from flask import Flask, render_template, request, redirect, url_for, flash
import json, os, random, statistics
app=Flask(__name__); app.secret_key="dev-only-change-me"
FILE="customers.json"
SEED=[
{"id":"C001","name":"Andi Pratama","category":"Regular","balance":8500000},
{"id":"C002","name":"Budi Santoso","category":"Regular","balance":7900000},
{"id":"C003","name":"Citra Lestari","category":"Premium","balance":9100000},
{"id":"C004","name":"Deni Kurniawan","category":"Regular","balance":8200000},
{"id":"C005","name":"Eka Putri","category":"Premium","balance":8700000},
{"id":"C006","name":"Fajar Hidayat","category":"Regular","balance":7600000},
{"id":"C007","name":"Gita Maharani","category":"Premium","balance":9400000},
{"id":"C008","name":"Hadi Saputra","category":"Regular","balance":8300000}]
def load():
 if not os.path.exists(FILE): save(SEED)
 with open(FILE,encoding="utf-8") as f:return json.load(f)
def save(x):
 with open(FILE,"w",encoding="utf-8") as f:json.dump(x,f,indent=2,ensure_ascii=False)
def stats(rows):
 v=[float(x["balance"]) for x in rows]
 return {"count":len(v),"mean":statistics.mean(v) if v else 0,"median":statistics.median(v) if v else 0,"sd":statistics.stdev(v) if len(v)>1 else 0,"lo":min(v) if v else 0,"hi":max(v) if v else 0}
def generate(rows,method):
 s=stats(rows); out=[]
 if not rows:return out
 for i in range(5):
  if method=="adaptive":
   amount=random.gauss(s["mean"],s["sd"] or s["mean"]*.05)
   amount=max(s["lo"],min(s["hi"],amount)); cat=random.choice([r["category"] for r in rows])
  else:
   amount=random.uniform(s["mean"]*.25,s["mean"]*2); cat=random.choice(["Basic","Regular","Premium","VIP"])
  out.append({"id":f"DECOY-{i+1:03}","name":random.choice(rows)["name"],"category":cat,"balance":round(amount/1000)*1000})
 return out
@app.route("/")
def home():
 r=load();return render_template("index.html",rows=r,s=stats(r))
@app.post("/add")
def add():
 r=load(); name=request.form.get("name","").strip()
 try:
  bal=float(request.form.get("balance",""))
  if not name or bal<0:raise ValueError()
 except ValueError:
  flash("Nama dan saldo harus valid.");return redirect(url_for("home"))
 r.append({"id":f"C{len(r)+1:03}","name":name,"category":request.form.get("category","Regular"),"balance":bal});save(r)
 flash("Pelanggan ditambahkan.");return redirect(url_for("home"))
@app.route("/simulation",methods=["GET","POST"])
def simulation():
 r=load(); method=request.form.get("method","adaptive"); result=generate(r,method) if request.method=="POST" else None
 return render_template("simulation.html",s=stats(r),result=result,method=method)
@app.post("/reset")
def reset():save(SEED);flash("Dataset contoh dipulihkan.");return redirect(url_for("home"))
if __name__=="__main__":app.run(debug=True)
